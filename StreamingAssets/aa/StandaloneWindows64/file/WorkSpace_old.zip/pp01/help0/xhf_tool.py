#!/usr/bin/env python3
"""
xhf_tool.py  --  Xenosaga Pied Piper .xhf extract / rebuild

사용법:
  python xhf_tool.py extract  help0.xhf  [out.txt]
  python xhf_tool.py rebuild  help0.xhf  in.txt    [out.xhf]

txt 형식:
  ## TOC
  TOC:0:텍스트
  ...

  ## SEC:1
  XREF:0B:00:08E8   <- 포인터. 절대 수정하지 말 것.
  0:텍스트
  1:텍스트

  ## SEC:2
  ...

번역:
  - 콜론 두 번째 이후가 텍스트. 앞 번호는 그대로 둘 것.
  - 한글 입력 가능. xenosaga_charmap.json이 같은 폴더에 있어야 함.
  - 한자들은 charmap 기준 한글로 표시됨 (예: 目的 -> 目퀼). 그대로 두거나 번역.
"""

import sys, os, json

CHARMAP_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'xenosaga_charmap.json')

def load_charmap():
    cm = json.load(open(CHARMAP_PATH, 'r', encoding='utf-8'))
    return cm['char_to_sjis']

def enc(text, c2s):
    """charmap 우선, 없으면 표준 shift-jis 폴백 (한글은 charmap, 한자는 폴백)"""
    b = []
    for ch in text:
        v = c2s.get(ch)
        if v:
            if v[0] == 0:
                b.append(v[1])
            else:
                b.extend(v)
        else:
            try:
                b.extend(ch.encode('cp932'))
            except:
                b.append(0x3F)
    return bytes(b)

def dec_sjis(raw_bytes):
    """CP932 디코딩 (NEC 특수문자 포함)"""
    return raw_bytes.decode('cp932', 'replace')

# ── 파서 ────────────────────────────────────────────────────
def parse(data):
    ff_pos = [i for i in range(len(data)) if data[i] == 0xFF]
    clusters = []; prev = -100; group = []
    for p in ff_pos:
        if p - prev == 4:
            group.append(p)
        else:
            if group: clusters.append(group)
            group = [p]
        prev = p
    if group: clusters.append(group)
    RC = [cl for cl in clusters
          if (cl[0]-1 < 3) or
             (cl[0]-1 >= 2 and data[cl[0]-3] == 0 and data[cl[0]-2] == 0)]

    TOC_POOL_START = 0x3D
    TOC_MYSTERY    = data[0x3C]

    toc = []
    for i in range(0, 0x3C, 4):
        length = data[i]; cid = data[i+1]
        offset = int.from_bytes(data[i+2:i+4], 'big')
        raw = data[offset:]
        null = next((j for j, b in enumerate(raw) if b == 0), -1)
        rb = list(raw[:null]) if null >= 0 else list(raw[:20])
        toc.append({'len': length, 'id': cid, 'offset': offset,
                    'raw': rb, 'text': dec_sjis(bytes(rb))})

    sections = []
    for idx, cl in enumerate(RC):
        idx_end = cl[-1] + 3; tsf = idx_end + 1
        txt_end = (RC[idx+1][0] - 3) if idx+1 < len(RC) else len(data)
        ff_entries = [{'len': data[p-1], 'offset': (data[p+1] << 8) | data[p+2]} for p in cl]
        extra = data[idx_end]
        xrefs = []; p = tsf
        while p < txt_end - 3:
            b = data[p]
            if b >= 0x20 or b == 0x00: break
            xrefs.append({'id': b, 'type': data[p+1], 'raw': list(data[p:p+4]),
                          'offset_le': data[p+2] | (data[p+3] << 8)})
            p += 4
        real_txt = p; lines = []; p = real_txt
        while p < txt_end:
            end = data.find(b'\x00', p)
            if end == -1 or end >= txt_end: end = txt_end
            chunk = data[p:end]
            if chunk:
                lines.append({'offset': p - real_txt, 'abs': p,
                              'raw': list(chunk), 'text': dec_sjis(chunk)})
            p = end + 1
        sections.append({'idx': idx+1, 'ff_entries': ff_entries, 'extra': extra,
                         'xrefs': xrefs, 'lines': lines,
                         'real_txt': real_txt, 'txt_end': txt_end})

    def map_ff(ff_entries, lines):
        mapped = []
        for e in ff_entries:
            off = e['offset']; lf = None; inner = off
            for li, line in enumerate(lines):
                ls = line['offset']; le = ls + len(line['raw'])
                if ls <= off <= le + 1:
                    lf = li; inner = off - ls; break
            mapped.append({'li': lf, 'inner': inner, 'len': e['len']})
        return mapped

    def map_xref(xrefs, sections):
        mapped = []
        for xr in xrefs:
            ao = xr['offset_le']; ts = None; tl = None; inner = 0
            for si, sec in enumerate(sections):
                if ao == sec['real_txt']: ts = si; tl = -1; break
                for li, line in enumerate(sec['lines']):
                    ls = line['abs']; le = ls + len(line['raw'])
                    if ls <= ao <= le: ts = si; tl = li; inner = ao - ls; break
                if ts is not None: break
            mapped.append({'ts': ts, 'tl': tl, 'inner': inner})
        return mapped

    for sec in sections:
        sec['ff_mapped']   = map_ff(sec['ff_entries'], sec['lines'])
        sec['xref_mapped'] = map_xref(sec['xrefs'], sections)

    return toc, sections, TOC_POOL_START, TOC_MYSTERY

# ── 리빌드 ──────────────────────────────────────────────────
def rebuild(toc, sections, edits_toc, edits_sec, TOC_POOL_START, TOC_MYSTERY, c2s):
    sec_data = []
    for si, sec in enumerate(sections):
        se = edits_sec.get(si, {})
        new_lines = [enc(se[li], c2s) if li in se else bytes(line['raw'])
                     for li, line in enumerate(sec['lines'])]

        # orig_offset 유지: 이전 라인이 길어지면 다음 라인이 밀림
        # 번역이 원본보다 짧으면 원본 나머지 바이트로 채워 FF inner 보장
        orig_offsets = [line['offset'] for line in sec['lines']]
        orig_raws    = [bytes(line['raw']) for line in sec['lines']]
        txt = bytearray(); new_off = []; pos = 0
        for li, lb in enumerate(new_lines):
            target = orig_offsets[li]
            if pos < target:
                txt += b'\x00' * (target - pos)
                pos = target
            new_off.append(pos)
            orig_raw = orig_raws[li]
            if len(lb) < len(orig_raw):
                # 짧은 번역: 나머지를 원본 바이트로 채움 (FF inner 위치 보존)
                combined = lb + orig_raw[len(lb):]
            else:
                combined = lb
            txt += combined + b'\x00'
            pos = new_off[li] + len(combined) + 1
        # 마지막 null이 섹션 double-null의 첫 바이트를 겸함
        if txt.endswith(b'\x00'):
            txt = txt[:-1]

        ff = bytearray()
        for fm in sec['ff_mapped']:
            li = fm['li']; inner = fm['inner']
            no = (new_off[li] + inner) if (li is not None and li < len(new_off)) else inner
            ff += bytes([fm['len'], 0xFF, (no >> 8) & 0xFF, no & 0xFF])
        ff += bytes([sec['extra']])

        xref = bytearray()
        for xr in sec['xrefs']: xref += bytes(xr['raw'])

        sec_data.append({'ff': ff, 'xref': xref, 'txt': bytes(txt),
                         'new_off': new_off, 'new_lines': new_lines})

    toc_pool = bytearray(); toc_abs = []
    for ti, t in enumerate(toc):
        tb = enc(edits_toc[ti], c2s) if ti in edits_toc else bytes(t['raw'])
        toc_abs.append(TOC_POOL_START + len(toc_pool))
        toc_pool += tb + b'\x00\x00'

    toc_hdr = bytearray()
    for ti, t in enumerate(toc):
        tb = enc(edits_toc[ti], c2s) if ti in edits_toc else bytes(t['raw'])
        off = toc_abs[ti]
        toc_hdr += bytes([t['len'], t['id'], (off >> 8) & 0xFF, off & 0xFF])

    base = TOC_POOL_START + len(toc_pool)
    sec_pos = []
    for sd in sec_data:
        sec_pos.append(base)
        base += len(sd['ff']) + len(sd['xref']) + len(sd['txt']) + 2

    for si, sec in enumerate(sections):
        for xi, xm in enumerate(sec['xref_mapped']):
            ts = xm['ts']; tl = xm['tl']; inner = xm['inner']
            if ts is None:
                new_abs = sec['xrefs'][xi]['offset_le']
            elif tl == -1:
                new_abs = sec_pos[ts] + len(sec_data[ts]['ff']) + len(sec_data[ts]['xref'])
            elif tl < len(sec_data[ts]['new_off']):
                new_abs = (sec_pos[ts] + len(sec_data[ts]['ff'])
                           + len(sec_data[ts]['xref'])
                           + sec_data[ts]['new_off'][tl] + inner)
            else:
                new_abs = sec['xrefs'][xi]['offset_le']
            xb = sec_data[si]['xref']
            xb[xi*4+2] = new_abs & 0xFF
            xb[xi*4+3] = (new_abs >> 8) & 0xFF

    out = bytearray()
    out += toc_hdr + bytes([TOC_MYSTERY]) + toc_pool
    for sd in sec_data:
        out += sd['ff'] + sd['xref'] + sd['txt'] + b'\x00\x00'
    return bytes(out)

# ── extract ─────────────────────────────────────────────────
def cmd_extract(xhf_path, txt_path):
    c2s = load_charmap()
    data = open(xhf_path, 'rb').read()
    toc, sections, _, _ = parse(data)

    lines = []
    lines.append('## TOC')
    for ti, t in enumerate(toc):
        lines.append(f'TOC:{ti}:{t["text"]}')
    lines.append('')
    for sec in sections:
        lines.append(f'## SEC:{sec["idx"]}')
        for xr in sec['xrefs']:
            lines.append(f'XREF:{xr["id"]:02X}:{xr["type"]:02X}:{xr["offset_le"]:04X}')
        for li, line in enumerate(sec['lines']):
            lines.append(f'{li}:{line["text"]}')
        lines.append('')

    open(txt_path, 'w', encoding='utf-8').write('\n'.join(lines))
    total = sum(len(sec['lines']) for sec in sections)
    print(f'추출 완료: {txt_path}  (TOC {len(toc)}개, 섹션 {len(sections)}개, 줄 {total}개)')

# ── rebuild ─────────────────────────────────────────────────
def cmd_rebuild(xhf_path, txt_path, out_path):
    c2s = load_charmap()
    data_orig = open(xhf_path, 'rb').read()
    toc, sections, TOC_POOL_START, TOC_MYSTERY = parse(data_orig)

    edits_toc = {}; edits_sec = {}; cur_sec = None
    for raw_line in open(txt_path, 'r', encoding='utf-8'):
        line = raw_line.rstrip('\n')
        if line.startswith('## TOC'):
            cur_sec = 'toc'
        elif line.startswith('## SEC:'):
            cur_sec = int(line[7:]) - 1
        elif line.startswith('XREF:') or line == '' or line.startswith('#'):
            pass
        elif cur_sec == 'toc' and line.startswith('TOC:'):
            parts = line.split(':', 2)
            if len(parts) == 3:
                edits_toc[int(parts[1])] = parts[2]
        elif isinstance(cur_sec, int):
            parts = line.split(':', 1)
            if len(parts) == 2 and parts[0].isdigit():
                li = int(parts[0])
                edits_sec.setdefault(cur_sec, {})[li] = parts[1]

    result = rebuild(toc, sections, edits_toc, edits_sec,
                     TOC_POOL_START, TOC_MYSTERY, c2s)
    open(out_path, 'wb').write(result)
    print(f'리빌드 완료: {out_path}  ({len(result)} bytes)')

# ── main ────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd = sys.argv[1]
    if cmd == 'extract':
        xhf = sys.argv[2]
        txt = sys.argv[3] if len(sys.argv) > 3 else xhf.replace('.xhf', '.txt')
        cmd_extract(xhf, txt)
    elif cmd == 'rebuild':
        if len(sys.argv) < 4:
            print('rebuild: xhf와 txt 경로 필요'); sys.exit(1)
        xhf = sys.argv[2]; txt = sys.argv[3]
        out = sys.argv[4] if len(sys.argv) > 4 else xhf.replace('.xhf', '_out.xhf')
        cmd_rebuild(xhf, txt, out)
    else:
        print(f'알 수 없는 명령: {cmd}'); sys.exit(1)

if __name__ == '__main__':
    main()
